declare module '*.scss';

declare module '*.png';
