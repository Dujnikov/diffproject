package aeca.aladdin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppSAE {
    public static void main(String[] args) {
        SpringApplication.run(AppSAE.class, args);
    }
}
