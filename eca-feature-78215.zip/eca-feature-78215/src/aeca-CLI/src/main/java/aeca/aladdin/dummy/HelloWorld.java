package aeca.aladdin.dummy;

public class HelloWorld {

    public void printHello() {
        System.out.println("Hello world");
    }
}
