package aeca.aladdin.domain.dto;

public class IdDTO {

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}