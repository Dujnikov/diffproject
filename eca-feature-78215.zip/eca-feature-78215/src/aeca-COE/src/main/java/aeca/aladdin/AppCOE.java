package aeca.aladdin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppCOE {
    public static void main(String[] args) {
        SpringApplication.run(AppCOE.class, args);
    }
}
